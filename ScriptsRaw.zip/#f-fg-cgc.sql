update mensal set fg = 'N' where fg is null or char_length(trim(fg)) = 0;
update mensal set fgnumeroato = null, fgdataato = null, fgveiculopublicacaoato = null, fgdatainicio = null where fg = 'N';
update financeiro set ad = 'N' where ad is null or char_length(trim(ad)) = 0;
update financeiro set cgc = 'N' where cgc is null or char_length(trim(cgc)) = 0;
update financeiro set addatainicio = addataato where addatainicio is null and addataato is not null and ano >= 2025;
update financeiro set addataato = addatainicio where addataato is null and addatainicio is not null and ano >= 2025;
update financeiro set adnumeroato = null, addataato = null, addatainicio = null, adveiculopublicacaoato = null where cgc = 'N' and ad = 'N';